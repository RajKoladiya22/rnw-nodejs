 const express = require('express');

 const port = 8000;
 
 const app = express();

 app.set('view engine','ejs');

 let record = [
    {
        id : 1,
        name : "raj",
        phone : 1234
    },
    {
        id  : 2,
        name : "hari",
        phone : 6789
    }
 ]

 //middleware
 app.use(express.urlencoded());
 app.get('/',(req,res)=>{
    return res.render('index',{
        record
    });
 })

 app.get('/add',(req,res)=>{
    return res.render('add');
 })
 app.post('/addUser',(req,res)=>{
    let name = req.body.username;
    let phone = req.body.userphone;
    if(!name || !phone){
        console.log("All filed is required");
        return res.redirect('back');
    }
    let obj = {
        id : Math.floor(Math.random() * 100000),
        name,
        phone
    }
    record.push(obj);
    console.log("User successfully add");
    return res.redirect('/'); 
 })


 app.listen(port,(err)=>{
    if(err){
        console.log(err);
        return false;
    }
    console.log(`running :- ${port}`);
 })